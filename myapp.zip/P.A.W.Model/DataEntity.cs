﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PAW.Model
{
    public class DataEntity
    {
        public Guid Id { get; set; }
    }
}
